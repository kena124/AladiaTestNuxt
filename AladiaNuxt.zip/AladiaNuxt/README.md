# Test project

This is a test project which implements Nuxt.js and storybook.

The implementation is a dynamic form with Dark and Light mode.

## How to run

1. Clone the repository
1. Run `npm install`
1. Run `npm run dev` to start the Nuxt.js server
1. Run `npm run storybook` to start the Storybook server
