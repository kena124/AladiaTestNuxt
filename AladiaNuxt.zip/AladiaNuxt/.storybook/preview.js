/** @type { import('@storybook/vue3').Preview } */
import { setup } from "@storybook/vue3";
import ElementPlus from "element-plus";
import "element-plus/dist/index.css";
import "../assets/styles/tokens.scss";

const themes = [
  { name: "light", class: "light-theme", color: "#ffffff" },
  { name: "dark", class: "dark-theme", color: "#333333" },
];

export const decorators = [
  (story, context) => {
    const theme = context.globals.theme || "light";

    document.documentElement.setAttribute("data-theme", theme);

    return {
      components: { story },
      template: "<story />",
    };
  },
];

setup((app) => {
  app.use(ElementPlus);
});

const preview = {
  parameters: {
    themes: {
      default: "light",
      list: themes,
    },
    docs: {
      theme: null,
    },
    controls: {
      matchers: {
        color: /(background|color)$/i,
        date: /Date$/,
      },
    },
    actions: { argTypesRegex: "^on[A-Z].*" },
  },
  globalTypes: {
    theme: {
      name: "Theme",
      description: "Global theme for components",
      defaultValue: "light",
      toolbar: {
        icon: "circlehollow",
        items: ["light", "dark"],
        showName: true,
      },
    },
  },
};

export default preview;
