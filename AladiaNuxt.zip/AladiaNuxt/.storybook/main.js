/** @type { import('@storybook/vue3-vite').StorybookConfig } */
import { mergeConfig } from "vite";
import vue from "@vitejs/plugin-vue";
import path from "path";

const config = {
  stories: [
    "../stories/**/*.mdx",
    "../stories/**/*.stories.@(js|jsx|mjs|ts|tsx)",
    "../components/**/*.stories.@(js|jsx|ts|tsx|mdx)",
    "../pages/**/*.stories.@(js|jsx|ts|tsx|mdx)",
  ],
  addons: [
    "@storybook/addon-essentials",
    "@storybook/addon-links",
    "@storybook/addon-interactions",
  ],
  framework: {
    name: "@storybook/vue3-vite",
    options: {},
  },
  async viteFinal(config) {
    return mergeConfig(config, {
      plugins: [vue()],
      resolve: {
        alias: {
          "@": path.resolve(__dirname, "../"),
          "~": path.resolve(__dirname, "../"),
        },
      },
    });
  },
};

export default config;
